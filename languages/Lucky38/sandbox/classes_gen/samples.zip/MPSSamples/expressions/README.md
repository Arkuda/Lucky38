Expressions
===========

A simple and not very user friendly expression language for numeric or boolean formulas that is suitable for initial experimenting with the MPS Type-system Trace tool.
See the [Typesystem Debugging](http://confluence.jetbrains.com/display/MPSD30/Typesystem+Debugging) cookbook.