Generator Demo
==============

A set of languages and sample projects completed as a result of the [Generator Demos tutorial](http://confluence.jetbrains.com/display/MPSD30/Generator+Demos).
They illustrate the most frequently used techniques for defining generators.
